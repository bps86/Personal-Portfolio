This game was made for early training/test on Unity Engine at Red Rain Studio. 
This is the first game I made on Unity Engine, there will be imperfection in terms of code. 
Splash Animation, UI, and In-Game Assets are made by myself. 
The soundtrack was obtained from freesound, link: https://freesound.org/people/torn.rugged.audio.35/sounds/45737/
